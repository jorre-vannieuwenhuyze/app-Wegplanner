makeresult <- function(path,breedte) {HTML(
  wrongcombination("
  <p>Een snelheidsregime van 70km/u veronderstelt dat de weg in gebied ligt met weinig bebouwing. Het heeft geen zin om de snelheid van fietsers hier te beperken tot 30km/u.</p>
  <p>Fietsers hebben hier ook nood aan een 'Ontsluitingsweg' of 'Verbindingsweg' aan 50km/u. Pas jouw selectie aan in het menu.</p>
  ")
)}