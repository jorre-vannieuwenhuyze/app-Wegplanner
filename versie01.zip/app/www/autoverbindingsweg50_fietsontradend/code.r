makeresult <- function(path,breedte) {HTML(
  wrongcombination("
  <p>Een snelheidsregime van 50km/u op een verbindings- of ontsluitingsweg voor gemotoriseerd verkeer veronderstelt dat de weg in bebouwd gebied ligt. Het heeft geen zin om hier fietsen te ontraden.</p>
  <p>Fietsers hebben hier ook nood aan een 'Lokale toegangsweg', 'Ontsluitingsweg' of een 'Verbindingsweg'. Pas jouw selectie aan in het menu.</p>
  ")
)}