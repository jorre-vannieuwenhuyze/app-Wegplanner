#autotoegangsweg_fietsverbindingsweg50
makeresult <- function(path,breedte) {HTML(
  wrongcombination("
  <p>Een ontsluitings-/verbindingsweg met snelheidsregime van 30km/u voor gemotoriseerd verkeer is moeilijk combineerbaar met een fietsweg waarop 50km/u mag gereden worden.</p>
  <p>Gemotoriseerd verkeer heeft hier ook nood aan een 'Ontsluitingsweg' of 'Verbindingsweg' van 50km/u of fietsers mogen hier ook maximaal 30km/u. Pas jouw selectie aan in het menu.</p>
  ")
  )}